package asteroids.participants;
import static asteroids.game.Constants.*;
import java.awt.Shape;
import java.awt.geom.*;
import asteroids.game.Participant;
import asteroids.game.ParticipantCountdownTimer;


public class Debris extends Participant
{
    private Shape outline;
    /*
     * Debris after the ship or alien ship is destroyed. Debris will disappear after a short period of time
     */
    public Debris (double x, double y)
    {
        Path2D.Double explode = new Path2D.Double();
        explode.moveTo(20, 0);
        explode.lineTo(3, 2);

        setPosition(x, y);
        setVelocity(1.5, RANDOM.nextDouble() * 2 * Math.PI);
        setRotation(2 * Math.PI * RANDOM.nextDouble());

        outline = explode;
        new ParticipantCountdownTimer(this, "debris", 1200);
    }

    @Override
    protected Shape getOutline ()
    {
        // TODO Auto-generated method stub
        return outline;
    }

    @Override
    public void collidedWith (Participant p)
    {
        // TODO Auto-generated method stub
        
    }
   //Delay 
    @Override
    public void countdownComplete (Object payload)

    {
        // I think it works like this
        if (payload.equals("debris"))
        {
            expire(this);

        }

    }
}
