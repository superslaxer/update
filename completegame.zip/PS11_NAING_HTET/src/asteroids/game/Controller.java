package asteroids.game;

import static asteroids.game.Constants.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import javax.swing.*;
import asteroids.participants.AlienBullet;
import asteroids.participants.AlienShip;
import asteroids.participants.Asteroid;
import asteroids.participants.Bullet;
import asteroids.participants.Ship;
import asteroids.participants.Lives;

/**
 * Controls a game of Asteroids.
 */
public class Controller implements KeyListener, ActionListener, Iterable<Participant>
{
    /** The state of all the Participants */
    private ParticipantState pstate;

    /** The ship (if one is active) or null (otherwise) */
    private Ship ship;
    private Bullet bullet;
    private AlienShip alienShip;
    private AlienBullet alienBullet;
    private Asteroid asteroid;

    /** When this timer goes off, it is time to refresh the animation */
    private Timer refreshTimer;

    /**
     * The time at which a transition to a new stage of the game should be made. A transition is scheduled a few seconds
     * in the future to give the user time to see what has happened before doing something like going to a new level or
     * resetting the current level.
     */
    private long transitionTime;// transition just before facing the boss

    /** Number of lives left */
    private int lives;

    /** The game display */
    private Display display;

    /**
     * Constructs a controller to coordinate the game and screen
     */
    /*
     * variables and initial conditions which will be used in the programme
     */
    private boolean left;
    private boolean right;
    private boolean fireBullet;
    private boolean fireRate;
    private boolean alienStatus;
    private int acc;
    private int level;
    private int score;
    private boolean transitionCheck;
    private boolean teleport;
    private ArrayList<Bullet> ammo;
    /**A sound generator */
    private Sound sounds;
    
    private int finalScore;

    public Controller ()
    {

        sounds = new Sound();
        
        sounds.generateSound("BigAlienDead");
        sounds.generateSound("SmallAlienDead");
        // Initialize the ParticipantState
        pstate = new ParticipantState();

        // Set up the refresh timer.
        refreshTimer = new Timer(FRAME_INTERVAL, this);

        // Clear the transitionTime
        transitionTime = Long.MAX_VALUE;

        // Record the display object
        display = new Display(this);

        // Bring up the splash screen and start the refresh timer
        splashScreen();
        display.setVisible(true);
        refreshTimer.start();// timer starts here

    }

    /**
     * This makes it possible to use an enhanced for loop to iterate through the Participants being managed by a
     * Controller.
     */
    @Override
    public Iterator<Participant> iterator ()
    {
        return pstate.iterator();
    }

    /**
     * Returns the ship, or null if there isn't one
     */
    public Ship getShip ()
    {
        return ship;
    }

    /**
     * Configures the game screen to display the splash screen
     */
    private void splashScreen ()
    {
        // Clear the screen, reset the level, and display the legend
        clear();
        display.setLegend("Asteroids");

        // Place four asteroids near the corners of the screen.
        placeAsteroids();
    }

    /**
     * The game is over. Displays a message to that effect.
     */
    private void finalScreen ()
    {
        playSound("Beat1Dead");
        playSound("Beat2Dead");
        display.setLegend(GAME_OVER );
        
        display.removeKeyListener(this);
    }

    /**
     * Place a new ship in the center of the screen. Remove any existing ship first.
     */
    private void placeShip ()
    {
        // Place a new ship
        Participant.expire(ship);
        ship = new Ship(SIZE / 2, SIZE / 2, -Math.PI / 2, this);
        addParticipant(ship);
        display.setLegend("");
    }

    /**
     * Places an asteroid near one corner of the screen. Gives it a random velocity and rotation.
     */
    private void placeAsteroids ()
    {
        int xLeft = (int) (Math.random() * (100 - 0) + 0);
        // The y down coordinate
        int yDown = (int) (Math.random() * (800 - 700) + 700);
        // The left x coordinate
        int xRight = (int) (Math.random() * (700 - 600) + 600);
        // The y down coordinate
        int yUp = (int) (Math.random() * (100 - 0) + 0);

        int levelStatus = level;

        // These random numbers are used to generate random asteroid pieces to make the game seem more "realistic".
        int n = RANDOM.nextInt(3);

        int i = RANDOM.nextInt(3);
        int bigSpeed = RANDOM.nextInt(MAXIMUM_LARGE_ASTEROID_SPEED - 1);
        asteroid = new Asteroid(i, 0, xRight, yUp, bigSpeed + 1, this);
        addParticipant(asteroid);
        // addParticipant(new Asteroid(i, 2, xLeft, yUp, bigSpeed + 1, this));
        // addParticipant(new Asteroid(i, 2, xRight, yDown, bigSpeed + 1, this));
        // addParticipant(new Asteroid(i, 2, xLeft, yDown, bigSpeed + 1, this));
        bigSpeed = RANDOM.nextInt(MAXIMUM_LARGE_ASTEROID_SPEED - 1);

        while (levelStatus > 1)
        {
     
            if (n == 0)
            {
                asteroid = new Asteroid(n, 2, xLeft, yDown, bigSpeed + 1, this);
                addParticipant(asteroid);
            }
            if (n == 1)
            {
                asteroid = new Asteroid(n, 2, xRight, yDown, bigSpeed + 1, this);
                addParticipant(asteroid);
            }
            if (n == 2)
            {
                asteroid = new Asteroid(n, 2, xLeft, yUp, bigSpeed + 1, this);
                addParticipant(asteroid);
            }
            if (n == 3)
            {
                asteroid = new Asteroid(n, 2, xLeft, yDown, bigSpeed + 1, this);
                addParticipant(asteroid);
                n = 0;
            }

            levelStatus--;

            n++;
        }

    }

    /*
     * fire bullet in the direction of the ship
     */
    private void fireBullet ()
    {

        bullet = new Bullet(ship.getXNose(), ship.getYNose(), ship.getRotation());
        addParticipant(bullet);
        ammo.add(bullet);
        sounds.generateSound("Fire");
        //sounds.generateSound("Fire");


    }
    /**
     * generates a sound clip that is played String types 
     * Fire 
     * Thrust 
     * BigBang
     * SmallBang
     * MedBang
     * BangShip
     * BigAlien
     * SmallAlien
     * BangAlien
     * 
     * @param type the type of sound clip you want played.
     */
    public void playSound(String s)
    {
        sounds.generateSound(s);
    }

    /*
     * fire bullet from alien ship. Medium alien ship will fire bullet in random direction. Small alien ship will fire
     * bullet towards the ship
     * 
     */
    public void AlienFireBullet ()
    {
        if (alienShip.getSize() == 2 && ship != null)
        {
            double shoot = 2 * Math.PI * RANDOM.nextDouble();

            alienBullet = new AlienBullet(alienShip.getX(), alienShip.getY(), shoot);
            addParticipant(alienBullet);
        }
        else if (alienShip.getSize() == 1 && ship != null)
        {
            
            alienBullet = new AlienBullet(alienShip.getX(), alienShip.getY(), target());
            addParticipant(alienBullet);
        }

    }

    /*
     * Spawn alien ship after level 1. Medium alien ship will be spawned in level 2. Small alien ship will be spawned in
     * other levels
     */
    private void placeAlienShip ()
    {

        if (level == 2)
        {
            alienShip = new AlienShip(2, SIZE + 30, SIZE + 185, this);
            alienShip.respawn();

        }
        else
        {
            alienShip = new AlienShip(1, SIZE + 30, SIZE + 100, this);
            alienShip.respawn();

        }

    }

    /**
     * else if (e.getSource() == refreshTimer) { // It may be time to make a game transition performTransition();
     * 
     * // Move the participants to their new locations pstate.moveParticipants();
     * 
     * // Refresh screen display.refresh(); } Clears the screen so that nothing is displayed
     */
    private void clear ()
    {   sounds.canPlay(false);
    playSound("BigAlienDead");
    playSound("SmallAlienDead");
       
        sounds = new Sound();
        //sounds.resetTempo(2000);
  
        

        
       
        playSound("Start Music");
       
        pstate.clear();
        display.setLegend("");
        ship = null;

    
    }

    /**
     * Sets things up and begins a new game.
     */
    private void initialScreen ()
    {
        // Clear the screen
        clear();
        ammo = new ArrayList<Bullet>();// maximum bullet that can be on the screen, 8
        left = false;
        right = false;
        acc = 0;
        fireBullet = false;
        fireRate = true;
        alienShip = new AlienShip(0, 1, 1, this);// default alienShip
        transitionCheck = false; // not the time for transition yet
        alienStatus = false; // no alien ship at first
        level = 1; // the very start of the game
        score = 0;
        finalScore = score;// initiall the score is zero
        teleport = false;
 
        // Place asteroids
        placeAsteroids();

        // Place the ship

        placeShip();

        // Reset statistics
        lives = 3;// 3 lives
        getLives(lives);

        // Start listening to events (but don't listen twice)
        display.removeKeyListener(this);
        display.addKeyListener(this);

        // Give focus to the game screen
        display.requestFocusInWindow();
        playSound("StartMusic");

    }

    /**
     * Adds a new Participant
     */
    public void addParticipant (Participant p)
    {
        pstate.addParticipant(p);
    }

    /**
     * The ship has been destroyed. One life is lost at a time. If no life left, display the final screen.
     * 
     */
    public void shipDestroyed ()
    {
        // Null out the ship
        ship = null;

        // Display a legend
        display.setLegend("Ouch!");

        // Decrement lives
        lives--;
        livesLost();
        getLives(lives);
        if (lives > 0)
        {
            placeShip();
        }
        else
        {
            finalScreen();
            score = 0 ;
        }

        // Since the ship was destroyed, schedule a transition
        scheduleTransition(END_DELAY);
    }

    /*
     * Minus one life from the lives graphic
     */
    private void livesLost ()
    {
        // int count = 0;
        for (Participant p : this)
        {
            if (p instanceof Lives)
            {
                ((Lives) p).lifeLost();
            }

        }

    }

    /*
     * alien ship has been destroyed. Update the score
     */
    public void AlienShipDestroyed ()
    {

        scheduleTransition(END_DELAY);
        score = score + ALIENSHIP_SCORE[alienShip.getSize() - 1];
        alienStatus = true;

    }

    /**
     * An asteroid has been destroyed. If there are no asteroid left on the screen, proceed to the next level.
     */
    public void asteroidDestroyed ()// Animation and stuffs will happen here
    {
        // If all the asteroids are gone, schedule a transition

        if (countAsteroids() == 0)
        {
            level++;
            if (!alienShip.isExpired())
            {
                Participant.expire(alienShip);// remove the alien ship
            }
            sounds.canPlay(false);
            playSound("BigAlienDead");
            playSound("SmallAlienDead");
            sounds = new Sound();  
            scheduleTransition(END_DELAY);

            transitionCheck = true;
        }

    }

    public void updateScore (int i)
    {
        if (i == 2)
        {
            score = score + 20;
        }
        if (i == 1)
        {
            score = score + 50;
        }

        if (i == 0)
        {
            score = score + 100;
        }
        if(i == 3) {
            score = score + 200;
        }
        
        if(i == 4) {
            score = score + 1000;
        }
        finalScore = score;
    }

    /**
     * Schedules a transition m msecs in the future
     */
    private void scheduleTransition (int m)// the desire transition time
    {
        transitionTime = System.currentTimeMillis() + m;
    }

    /**
     * This method will be invoked because of button presses and timer events.
     */
    @Override
    public void actionPerformed (ActionEvent e)
    {

        // The start button has been pressed. Stop whatever we're doing
        // and bring up the initial screen
        if (e.getSource() instanceof JButton)
        {
            initialScreen();

        }

        // Time to refresh the screen and deal with keyboard input
        else if (e.getSource() == refreshTimer)
        {

            performTransition();// may be it is time to switch to next level
            alienShipSpawn();// alienShip re-spawn after 5 seconds
            if (ship != null)
            {

                if (left == true)// ship turns left
                {
                    ship.turnLeft();

                }
                if (right == true)// ship turns right
                {
                    ship.turnRight();

                }
                if (teleport == true)// teleportation
                {
                    ship.teleport();
                    teleport = false;

                }

                if (fireBullet == true)// ship shoots bullet
                {
                    if (ammo.size() > 8)// check max number of bullet
                    {
                        fireRate = false;
                        if (ammo.get(0).isExpired())
                        {
                            ammo.remove(0);
                            fireRate = true;
                        }

                    }
                    else
                    {
                        fireBullet();
                     

                        //fireBullet = false;
                    }

                }
                if (acc == 1 && ship != null)// draw flame when ship accelerates
                {
                    Random rand = new Random();
                    int n = rand.nextInt(2);
                    if (n == 1)
                    {
                        ship.drawaltFlame();
                    }
                    else
                    {
                        ship.drawFlame();
                    }
                    ship.accelerate();
                    sounds.generateSound("Thrust");
                }
                else if (acc == 2 && ship != null)
                {
                    ship.decelerate();
                }
                pstate.moveParticipants();
                display.refresh();

            }
            else
            {
                pstate.moveParticipants();
                display.refresh();
            }

        }

    }

    /**
     * If the transition time has been reached, transition to a new state Place the alien ship
     */
    private void performTransition ()
    {
        // System.out.println("ok");

        if (transitionCheck == true)
        {

            // Do something only if the time has been reached
            if (transitionTime <= System.currentTimeMillis())
            {

                // If there are no lives left, the game is over. Show the final
                // screen.
                if (lives <= 0)
                {
                    finalScreen();
                    score = 0;
                }
                else
                {
//                    sounds.resetTempo(2000);
//                    sounds.canPlay(true);
                    sounds.generateSound("Start Music");
                   placeAsteroids();
                    placeAlienShip();

                    transitionCheck = false;

                }
                transitionTime = Long.MAX_VALUE;

            }

        }

    }//

    /*
     * re-spawn alienShip after 5 seconds
     */
    private void alienShipSpawn ()
    {
        if (alienStatus == true)
            if (transitionTime <= System.currentTimeMillis())
            {

                // Clear the transition time
                transitionTime = Long.MAX_VALUE;
                placeAlienShip();// place AlienShip
            
                alienStatus = false;

            }
    }

    /**
     * Returns the number of asteroids that are active participants
     */
    private int countAsteroids ()
    {
        int count = 0;
        for (Participant p : this)
        {
            if (p instanceof Asteroid)
            {
                count++;
            }
        }
        return count;
    }

    /*
     * Returns the number of asteroids present on screen
     */
    public int getAsteroidCounts ()
    {
        return countAsteroids();
    }

    /*
     * Returns current level
     */
    public String getLevel ()
    {
        String level = Integer.toString(this.level);
        return level;
    }

    /*
     * Returns current score
     */
    public String getScore ()
    {
        String score = Integer.toString(this.score);
        return score;
    }

    /*
     * Return current number of lives left. Draw remaining number of lives
     */
    public void getLives (int type)
    {
        // Manually draw how many lives there are.
        if (type == 1)
        {
            Lives first = new Lives(25, 75);
            this.addParticipant(first);

        }

        if (type == 2)
        {
            Lives first = new Lives(25, 75);
            this.addParticipant(first);
            // Second life
            Lives second = new Lives(55, 75);
            this.addParticipant(second);

        }

        if (type == 3)
        {
            Lives first = new Lives(25, 75);
            addParticipant(first);
            // Second life
            Lives second = new Lives(55, 75);
            addParticipant(second);
            Lives third = new Lives(85, 75);
            addParticipant(third);

        }

    }

    /**
     * If a key of interest is pressed, record that it is down.
     */
    @Override
    public void keyPressed (KeyEvent e)// add more keys
    {
        if ((e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) && ship != null)
        {
            acc = 1;
            //sounds.generateSound("Thrust");
            
        }
        if ((e.getKeyCode() == KeyEvent.VK_DOWN))
        {
            acc = 2;
        }
        if((e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) && ship != null)
        {

            right = true;
        }
        if ((e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) && ship != null)// turning left
        {
            // refreshTimer = new Timer(FRAME_INTERVAL, this);
            left = true;
        }
        if((e.getKeyCode() == KeyEvent.VK_SPACE || e.getKeyCode() == KeyEvent.VK_DOWN
                || e.getKeyCode() == KeyEvent.VK_S) && ship != null)
        {
            
                fireBullet = true;
                
           
          
        }
        if (e.getKeyCode() == KeyEvent.VK_T && ship != null)
        {
            teleport = true;
        }

    }

    @Override
    public void keyTyped (KeyEvent e)
    {
    }

    @Override
    public void keyReleased (KeyEvent e)
    {
        if ((e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) && ship != null)
        {
            acc = 0;
            ship.eraseFlame();
        }
        if ((e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) && ship != null)
        {
            right = false;
        }
        if ((e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) && ship != null)
        {
            left = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_DOWN && ship != null)
        {
            acc = 0;
            ship.eraseFlame();
        }
        if((e.getKeyCode() == KeyEvent.VK_SPACE || e.getKeyCode() == KeyEvent.VK_DOWN
                || e.getKeyCode() == KeyEvent.VK_S) && ship != null)
        {
            
            fireBullet = false;
        }
    }
/**
 * counts the number of Asteroids.
 * @return
 */
    public int counter ()
    {
        int count = 0;
        for (Participant p : this)
        {
            if (p instanceof Asteroid)
            {
                count++;
            }
        }
        return count;

    }
/**
 * gets the target for the alien ship to fire at.
 * @return
 */
    public double target ()
    {
        double x = ship.getX() - alienShip.getX();
        double y = ship.getY() - alienShip.getY();
        Random deviate = new Random();
        int z = deviate.nextInt(2);
        if (z == 0)
        {
            return (Math.atan2(y, x)) + PLUS_FIVE_DEGREE;
        }
        else
        {
            return (Math.atan2(y, x)) + MINUS_FIVE_DEGREE;
        }

    }

}
