package asteroids.participants;

import static asteroids.game.Constants.*;
import java.awt.Shape;
import java.awt.geom.*;
import java.util.Random;
import asteroids.destroyers.*;
import asteroids.game.Controller;
import asteroids.game.Participant;
import asteroids.game.ParticipantCountdownTimer;

public class AlienShip extends Participant implements ShipDestroyer
{
    private Shape outline;
    private int size;
    private boolean fire;

    /** Game controller */
    private Controller controller;

    private boolean change; // change the direciton of the ship

    /**
     * Constructs an alien ship at the specified coordinates that is pointed in the given direction. two types of alien
     * ship medium and small
     */
    public AlienShip (int size, int x, int y, Controller controller)
    {
        this.controller = controller;
        this.size = size;
        change = false;
        fire = false;

        setPosition(x, y);
        Path2D.Double poly = new Path2D.Double();
        changeDirection();// Random movement

        poly.moveTo(30, 0);
        poly.lineTo(-10, 30);
        poly.lineTo(0, 10);
        poly.lineTo(-7, 7);
        poly.lineTo(-3, 3);
        poly.lineTo(-3, -3);
        poly.lineTo(-7, -7);
        poly.lineTo(0, -10);
        poly.lineTo(-10, -30);
        poly.closePath();

        double scale = ASTEROID_SCALE[size];
        poly.transform(AffineTransform.getScaleInstance(scale, scale));
        outline = poly;

    }

    public void respawn ()
    {
        new ParticipantCountdownTimer(this, "respawn", 5000);
    }

    /*
     * Get outline
     */
    @Override
    protected Shape getOutline ()
    {

        return outline;
    }

    /*
     * Will be destroyed upon collision with the ship. The ship will also be destroyed
     */
    @Override
    public void collidedWith (Participant p)
    {
        if (p instanceof AsteroidDestroyer)

        {

            if (this.size == 2.0)
            {
                controller.playSound("BigAlienDead");
                controller.updateScore(3);
            }
            if (this.size == 1.0)
            {
                controller.playSound("SmallAlienDead");
                controller.updateScore(4);

            }
            Participant.expire(this);
            controller.playSound("BangAlien");
            rubbleEffect(this.getX(), this.getY());
            controller.AlienShipDestroyed();

        }
    }

    /*
     * When destroyed, debris will be scattered
     */
    private void rubbleEffect (double x, double y)
    {
        debris(controller, x, y);
    }

    /*
     * debris animation
     */
    private void debris (Controller controller, double x, double y)
    {
        for (int i = 0; i < 11; i++)
        {
            controller.addParticipant(new Debris(x, y));
        }
    }

    /*
     * get the size of the alien ship
     */
    public int getSize ()
    {
        return size;
    }

    /*
     * Random zig-zag movement of alien ship ship change direction after 5 seconds
     */
    public void move ()
    {

        if (change == true)
        {
            double direction = 0;
            Random point = new Random();
            int poinT = point.nextInt(4);
            if (poinT == 0)
            {
                direction = ALIEN_MOVE_HORZ;

            }
            else if (poinT == 1)
            {
                direction = ALIEN_MOVE_REV_HORZ;

            }
            else if (poinT == 2)
            {
                direction = ALIEN_MOVE_DOWN;

            }
            else if (poinT == 3)
            {
                direction = ALIEN_MOVE_UP;
            }
            setSpeed(0);
            setRotation(direction);
            if (this.getSize() == 1.0)
            {
                setVelocity(5, direction);
            }
            else
            {
                setVelocity(3, direction);
            }
            change = false;
            changeDirection();

            super.move();
        }
        else
        {
            if (this.getSize() == 1.0)
            {
                setSpeed(3);
            }
            else
            {
                setSpeed(5);
            }
            super.move();
        }

        if (fire == false)
        {
            fireBullet();

        }

    }

    /*
     * changeing Alien ship direction
     */
    private void changeDirection ()
    {
        new ParticipantCountdownTimer(this, "switch", 3000);

    }

    /*
     * Alien randomly fire bullet periodically, (after 1 s)
     */
    private void fireBullet ()
    {
        fire = true;
        new ParticipantCountdownTimer(this, "fire", 1000);
        controller.playSound("Fire2");

    }

    /*
     * Get the X position of alien ship tip
     */
    public double getAlienXNose ()
    {
        Point2D.Double point = new Point2D.Double(20, 0);
        transformPoint(point);
        return point.getX();
    }

    /*
     * Get the Y position of alien ship tip
     */
    public double getAlienYNose ()
    {
        Point2D.Double point = new Point2D.Double(20, 0);
        transformPoint(point);
        return point.getY();
    }

    /*
     * Delay for alien ship changing direction. Delay for alien ship firing bullet
     */
    @Override
    public void countdownComplete (Object ok)
    {
        if (ok.equals("switch"))
        {
            change = true;
            // change direction
        }
        else if (ok.equals("fire"))
        {
            controller.AlienFireBullet();
            fire = false;
        }
        if (ok.equals("respawn"))
        {
           

            if (this.size == 2.0)
            {
                controller.playSound("BigAlien");
            }
            if (this.size == 1.0)
            {
                controller.playSound("SmallAlien");

            }
            controller.addParticipant(this);
        }

    }

}
