package asteroids.game;

import java.awt.Shape;
/**
 * the purpose of this class is to have all the sounds on call for the controller class to use in the
 * game
 * 
 * @author krais
 *
 */
import java.io.BufferedInputStream;
import java.io.IOException;
import javax.sound.sampled.*;

public class Sound extends Participant
{
    /** A Clip that, when played, sounds like a weapon being fired */
    private Clip fireClip;

    /** A Clip that, when played repeatedly, sounds like a small saucer flying */
    private Clip smallSaucerClip;
    /** the Thrust sound */
    private Clip thrust;
    /** Each unique clip so it can be "PreLoaded" */
    private Clip bangAlien;

    private Clip bigBang;

    private Clip smallBang;

    private Clip bigAship;

    private Clip smallAship;

    private Clip bangShip;

    private Clip medBang;

    private Clip bigSaucer;

    private Clip beat1;

    private Clip beat2;
    
    private Clip fire2;
    
    

    /** Used for the weird beat music to increase its tempo */

    private int tempo;
    /** Used for the weird beat music to increase its tempo alternate */
    private int i;

    private boolean canPlay;

    public Sound ()
    {

        bangAlien = createClip("/sounds/bangAlienShip.wav");
        bigBang = createClip("/sounds/bangLarge.wav");
        medBang = createClip("/sounds/bangMedium.wav");
        bangShip = createClip("/sounds/bangShip.wav");
        smallBang = createClip("/sounds/bangSmall.wav");
        beat1 = createClip("/sounds/beat1.wav");
        beat2 = createClip("/sounds/beat2.wav");
        fireClip = createClip("/sounds/fire.wav");
        fire2 = createClip("/sounds/fire.wav");
        bigSaucer = createClip("/sounds/saucerBig.wav");
        smallSaucerClip = createClip("/sounds/saucerSmall.wav");
        thrust = createClip("/sounds/thrust.wav");

        beat1 = createClip("/sounds/beat1.wav");
        beat2 = createClip("/sounds/beat2.wav");

        tempo = 1000;
        i = 0;
        canPlay = true;

    }

    /**
     * method from the soundDemo class. Creates an audio clip from a sound file.
     * 
     * @param soundFile
     * @return
     */
    public Clip createClip (String soundFile)
    {
        // Opening the sound file this way will work no matter how the
        // project is exported. The only restriction is that the
        // sound files must be stored in a package.
        try (BufferedInputStream sound = new BufferedInputStream(getClass().getResourceAsStream(soundFile)))
        {
            // Create and return a Clip that will play a sound file. There are
            // various reasons that the creation attempt could fail. If it
            // fails, return null.
            Clip clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(sound));
            return clip;
        }
        catch (LineUnavailableException e)
        {
            return null;
        }
        catch (IOException e)
        {
            return null;
        }
        catch (UnsupportedAudioFileException e)
        {
            return null;
        }
    }

    /**
     * generates a sound clip that is played String types Fire Thrust BigBang SmallBang MedBang BangShip BigAlien
     * SmallAlien BangAlien BigAlienDead SmallAlienDead Beat1 Beat2
     * 
     * @param type the type of sound clip you want played.
     */
    public void generateSound (String type)
    {

        if (type.contentEquals("Fire"))
        {
//            if (fireClip.isRunning())
//            {
//                fireClip.stop();
//            }

            // Starts the sound
            fireClip.setFramePosition(0);

            fireClip.start();
        }
        
        if (type.contentEquals("Fire2"))
        {
//            if (fireClip.isRunning())
//            {
//                fireClip.stop();
//            }

            // Starts the sound
            fire2.setFramePosition(10);

           fire2.start();
        }

        if (type.contentEquals("Thrust"))
        {
            if (!thrust.isRunning())
            {
                thrust.setFramePosition(0);

                // thrust.start();

                thrust.loop(1);
            }
            else
            {
                if (thrust.getFramePosition() > 2000)
                {

                    // thrust.stop();

                }
            }

            // Starts the sound
            // thrust.setFramePosition(0);

            // thrust.start();
        }
        if (type.contentEquals("BigBang"))
        {
            if (bigBang.isRunning())
            {
                bigBang.setFramePosition(0);
                bigBang.start();
            }
            else
            {
                bigBang.setFramePosition(0);
                bigBang.start();
            }
        }

        if (type.contentEquals("SmallBang"))
        {
            if (smallBang.isRunning())
            {
                smallBang.setFramePosition(0);
                smallBang.start();
            }
            else
            {
                smallBang.setFramePosition(0);
                smallBang.start();
            }
        }

        if (type.contentEquals("MedBang"))
        {
            if (medBang.isRunning())
            {
                medBang.setFramePosition(0);
                medBang.start();
            }
            else
            {
                medBang.setFramePosition(0);
                medBang.start();
            }
        }

        if (type.contentEquals("BangShip"))
        {
            bangShip.setFramePosition(0);
            bangShip.start();

        }

        if (type.contentEquals("BigAlien"))
        {

            bigSaucer.setFramePosition(0);
            bigSaucer.loop(1999999999);

        }

        if (type.contentEquals("BigAlienDead"))
        {
            bigSaucer.stop();

        }

        if (type.contentEquals("SmallAlien"))
        {
            smallSaucerClip.setFramePosition(0);
            smallSaucerClip.loop(1999999999);

        }

        if (type.contentEquals("SmallAlienDead"))
        {
            smallSaucerClip.stop();

        }

        if (type.contentEquals("BangAlien"))
        {
            bangAlien.setFramePosition(0);
            bangAlien.start();

        }

        if (type.contentEquals("Beat1"))
        {
            beat1.setFramePosition(0);
            beat1.start();

        }

        if (type.contentEquals("Beat1Dead"))
        {

        }

        if (type.contentEquals("Beat2"))
        {
            beat2.setFramePosition(0);
            beat2.start();

        }
        if (type.contentEquals("Beat2Dead"))
        {
            beat2.stop();

        }
        if (type.contentEquals("Start Music"))
        {if(canPlay) {
            new ParticipantCountdownTimer(this, "music", tempo);
        }
        }

    }

    /**
     * for the weird beat music in the game
     */
    public void beats ()
    {
        if (tempo > 250)
        {
            tempo = tempo - 25;
        }
        if (canPlay == true)
        {
            generateSound("Start Music");
        }

        i++;
    }

    public void canPlay (boolean a)
    {
        if (a)
        {
            canPlay = true;
        }
        else
        {
            canPlay = false;
        }

    }

    /**
     * used to reset the tempo to the int i variable.
     * 
     * @param n
     */
    public void resetTempo (int n)
    {
        tempo = n;
        i = 0;
    }

    @Override
    protected Shape getOutline ()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void collidedWith (Participant p)
    {
        // TODO Auto-generated method stub

    }

    @Override
    public void countdownComplete (Object ok)
    {
        if (canPlay)
        {
            if (ok.equals("music"))
            {
                if (i % 2 == 0)
                {
                    generateSound("Beat1");
                    generateSound("Beat1Dead");
                }
                else
                {
                    generateSound("Beat2");
                    generateSound("Beat2Dead");
                }
               
                beats();
            }

        }
    }

}
