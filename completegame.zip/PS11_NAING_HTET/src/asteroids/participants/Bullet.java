package asteroids.participants;

import static asteroids.game.Constants.*;
import java.awt.Shape;
import java.awt.geom.*;
import asteroids.destroyers.*;
import asteroids.game.Asteroids;
import asteroids.game.Participant;
import asteroids.game.ParticipantCountdownTimer;

public class Bullet extends Participant implements AsteroidDestroyer
{
    private Shape outline;// shape of bullet
    double rotate;

    /*
     * Create bullet for the ship
     */
    public Bullet (double x, double y, double direction)
    {

        setPosition(x, y);
        // setDirection(direction);
        setRotation(direction);

        Path2D.Double poly = new Path2D.Double();
        if (Asteroids.getVersion() == 1)
        {
            poly.moveTo(0, 0);
            poly.lineTo(5, 0);
            poly.lineTo(0, 5);
            poly.lineTo(0, 0);
            poly.lineTo(-5, 0);
            poly.lineTo(0, -5);
            poly.lineTo(0, 5);
            poly.closePath();
        }
        else if (Asteroids.getVersion() == 2)
        {

            poly.moveTo(5, 0);
            poly.lineTo(-5, 30);
            poly.lineTo(0, 0);
            poly.lineTo(-5, -30);
            poly.closePath();
        }

        outline = poly;

        setVelocity(10, direction);
        new ParticipantCountdownTimer(this, "bullet", BULLET_DURATION);

    }

    /*
     * get outline
     */
    @Override
    protected Shape getOutline ()
    {
        // TODO Auto-generated method stub
        return outline;
    }

    /*
     * Bullet destroys asteroids as well as alien ship. Bullet will disappear after hitting target
     */
    @Override
    public void collidedWith (Participant p)
    {
        if (p instanceof ShipDestroyer)
        {
            // Assuming p is an asteroid
            Participant.expire(this);

            super.expire(this);
        }
    }

    /*
     * Bullet's motion
     */
    @Override
    public void move ()
    {
        setRotation(rotate++);
        setSpeed(15);
        super.move();
    }

    // Delay for bullet disappearing
    @Override
    public void countdownComplete (Object payload)

    {
        // I think it works like this
        if (payload.equals("bullet"))
        {
            expire(this);

        }

    }

}
