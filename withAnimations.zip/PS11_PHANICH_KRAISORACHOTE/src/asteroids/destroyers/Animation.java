package asteroids.destroyers;
/**
 * Used to mark animation objects
 * @author krais
 *
 */
public interface Animation
{

}
