package asteroids.participants;

import static asteroids.game.Constants.*;
import java.awt.Shape;
import java.awt.geom.*;
import asteroids.game.Participant;
import asteroids.game.ParticipantCountdownTimer;

public class Dust extends Participant
{
    
    /** The outline of the dust */
    private Shape outline;

    /*
     * Dust will appear when an asteroid is destroyed.
     * Dust will disappear after a short period of time
     */
    public Dust (double x, double y)
    {

        Path2D.Double sparkle = new Path2D.Double();
        sparkle.moveTo(2, 0);
        sparkle.lineTo(-1, 0);
        setPosition(x, y);
        setVelocity(1.5, RANDOM.nextDouble() * 2 * Math.PI);
        setRotation(2 * Math.PI * RANDOM.nextDouble());
        outline = sparkle;

        new ParticipantCountdownTimer(this, "dust", 1200);

    }

    @Override
    protected Shape getOutline ()
    {
        // TODO Auto-generated method stub
        return outline;
    }

    @Override
    public void collidedWith (Participant p)
    {
        // TODO Auto-generated method stub

    }
    //Delay
    @Override
    public void countdownComplete (Object payload)

    {
        // I think it works like this
        if (payload.equals("dust"))
        {
            expire(this);

        }

    }

}
