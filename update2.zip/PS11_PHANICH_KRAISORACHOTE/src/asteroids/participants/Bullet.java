package asteroids.participants;

import static asteroids.game.Constants.*;
import java.awt.Shape;
import java.awt.geom.*;
import asteroids.destroyers.*;
import asteroids.game.Controller;
import asteroids.game.Participant;
import asteroids.game.ParticipantCountdownTimer;

public class Bullet extends Participant implements AsteroidDestroyer
{

    /** The outline of the bullet */
    private Shape outline;

    /** Game controller */
    private Controller controller;

    /**
     * The constructor for the bullet
     */
    public Bullet (double x, double y, double direction, Controller controller)
    {
        this.controller = controller;
        // setPosition(x, y);
        // setRotation(direction);

        Path2D.Double poly = new Path2D.Double();
        // draws a ship LOL, change to some type of bullet.
        // Its a huge pain in the ass to draw using these methods
        // Maybe you could use a different shape?
        poly.moveTo(21, 0);
        poly.lineTo(-21, 12);
        poly.lineTo(-14, 10);
        poly.lineTo(-14, -10);
        poly.lineTo(-21, -12);

        poly.closePath();
        outline = poly;

        // Might fire the bullet from the ship
        setPosition(x, y);
        // Fire in the direction the ship is pointed.
        // This doesnt work like it should, I really dont know how the fuck direction works or even the poly object in
        // general, i feel like half the time it does the inverse of what i want it to do, hopefully you have better
        // luck than me
        setRotation(direction);

        accelerate(BULLET_SPEED);

        ;

    }

    /**
     * 
     * @param shipX
     * @param shpiY
     * @param shipDirection
     */
    public void shoot (double shipX, double shipY, double shipDirection)
    {
        // Might fire the bullet from the ship
        setPosition(shipX, shipY);
        // Fire in the direction the ship is pointed.
        setRotation(shipDirection);

        accelerate(BULLET_SPEED);

        // Set some type of timer here to get the bullet to explode.

    }

    /**
     * method used to update the location and animation of the particpant. Look at ship and asteroid idk if it needs any
     * more modification?
     * 
     */
    @Override
    protected Shape getOutline ()
    {
        // TODO Auto-generated method stub
        return outline;
    }

    @Override
    public void collidedWith (Participant p)
    {

        if (p instanceof ShipDestroyer)
        {
            // Assuming p is an asteroid
            Participant.expire(p);

            // Tell the controller the astroid was destroyed
            // downcast
            controller.asteroidDestroyed((Asteroid) p);
        }

    }

    /**
     * This method is invoked when a ParticipantCountdownTimer completes its countdown. Definitely needed to expire the
     * bullet after x amount of time has passed. to creates an object that triggers it use new
     * ParticipantCountdownTimer(this, "Some random string", 500);
     * 
     * might also be useful in limiting rate of fire
     * 
     * 
     */
    @Override
    public void countdownComplete (Object payload)

    {
        // I think it works like this
        if (payload == "Some random string")
        {
            // Set the bullet to expire
        }

    }

}
