package asteroids.game;

import static asteroids.game.Constants.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.*;
import asteroids.participants.Asteroid;
import asteroids.participants.Bullet;
import asteroids.participants.Effects;
import asteroids.participants.LifeSprite;
import asteroids.participants.Ship;
import java.util.Random;
import asteroids.game.ParticipantCountdownTimer;

/**
 * Controls a game of Asteroids.
 */
public class Controller implements KeyListener, ActionListener, Iterable<Participant>
{
    /** The state of all the Participants */
    private ParticipantState pstate;

    /** The ship (if one is active) or null (otherwise) */
    private Ship ship;

    /** When this timer goes off, it is time to refresh the animation */
    private Timer refreshTimer;

    private Bullet bullet;

    private boolean fireBullet;

    /**
     * The time at which a transition to a new stage of the game should be made. A transition is scheduled a few seconds
     * in the future to give the user time to see what has happened before doing something like going to a new level or
     * resetting the current level.
     */
    private long transitionTime;

    /** Number of lives left */
    private int lives;

    /** The game display */
    private Display display;

    /** used to update the turn of the ship with each frame. */

    private boolean left;

    /** used to update the turn of the ship with each frame. */

    private boolean right;

    /** used to make the acceleration smooth and current with every frame */
    private boolean acc;

    /** Keeps track of the current amount of bullets on the screen */
    private ArrayList<Bullet> ammo;

    /** Determines if the users can fire their bullet or not */
    private boolean fireRate;
    /** The current score of the game. */
    private int score;
    /** The current level of the game. */
    private int level;

    /**
     * Constructs a controller to coordinate the game and screen
     */
    public Controller ()
    {
        level = 1;
        score = 0;
        ammo = new ArrayList<Bullet>();
        // Initialize the ParticipantState
        pstate = new ParticipantState();
        fireRate = true;
        // Set up the refresh timer.
        refreshTimer = new Timer(FRAME_INTERVAL, this);// 33 mili seconds drives animation

        // Clear the transitionTime
        transitionTime = Long.MAX_VALUE;

        // Record the display object
        display = new Display(this);

        // Bring up the splash screen and start the refresh timer
        splashScreen();
        display.setVisible(true);
        // Timer starts here
        refreshTimer.start();
    }

    /**
     * This makes it possible to use an enhanced for loop to iterate through the Participants being managed by a
     * Controller.
     */
    @Override
    public Iterator<Participant> iterator ()
    {
        return pstate.iterator();
    }

    /**
     * Returns the ship, or null if there isn't one
     */
    public Ship getShip ()
    {
        return ship;
    }

    /**
     * Configures the game screen to display the splash screen
     */
    private void splashScreen ()
    {
        // Clear the screen, reset the level, and display the legend
        clear();
        display.setLegend("Asteroids");

        // Place four asteroids near the corners of the screen.
        placeAsteroids();
    }

    /**
     * The game is over. Displays a message to that effect.
     */
    private void finalScreen ()
    {
        display.setLegend(GAME_OVER);
        display.removeKeyListener(this);
    }

    /**
     * Place a new ship in the center of the screen. Remove any existing ship first. make new lives here.
     */
    private void placeShip ()
    {
        // Place a new ship
        Participant.expire(ship);
        // sHIP IS MADE HERE
        ship = new Ship(SIZE / 2, SIZE / 2, -Math.PI / 2, this);
        addParticipant(ship);
        display.setLegend("");
    }

    /**
     * Places an asteroid near one corner of the screen. Gives it a random velocity and rotation.
     */
    private void placeAsteroids ()
    {// Need to add randomness pretty easy to do

        // The left x coordinate
        int xLeft = (int) (Math.random() * (100 - 0) + 0);
        // The y down coordinate
        int yDown = (int) (Math.random() * (800 - 700) + 700);
        // The left x coordinate
        int xRight = (int) (Math.random() * (700 - 600) + 600);
        // The y down coordinate
        int yUp = (int) (Math.random() * (100 - 0) + 0);

        int levelStatus = level;

        // These random numbers are used to generate random asteroid pieces to make the game seem more "realistic".
        int n = RANDOM.nextInt(3);
        int i = RANDOM.nextInt(3);
        int bigSpeed = RANDOM.nextInt(MAXIMUM_LARGE_ASTEROID_SPEED - 1);
        //
        // addParticipant(new Asteroid(n, 2, xLeft, yDown, bigSpeed + 1, this));
        // bigSpeed = RANDOM.nextInt(MAXIMUM_LARGE_ASTEROID_SPEED - 1);
        // addParticipant(new Asteroid(i, 2, xLeft, yUp, bigSpeed + 1, this));
        // bigSpeed = RANDOM.nextInt(MAXIMUM_LARGE_ASTEROID_SPEED - 1);
        // addParticipant(new Asteroid(n, 2, xRight, yDown, bigSpeed + 1, this));
        // bigSpeed = RANDOM.nextInt(MAXIMUM_LARGE_ASTEROID_SPEED - 1);
        addParticipant(new Asteroid(i, 0, xRight, yUp, bigSpeed + 1, this));
        bigSpeed = RANDOM.nextInt(MAXIMUM_LARGE_ASTEROID_SPEED - 1);

        while (levelStatus > 1)
        {
            if (n == 1)
            {
                addParticipant(new Asteroid(n, 2, xLeft, yDown, bigSpeed + 1, this));
            }
            if (n == 2)
            {
                addParticipant(new Asteroid(i, 2, xLeft, yUp, bigSpeed + 1, this));
            }
            if (n == 3)
            {
                addParticipant(new Asteroid(n, 2, xRight, yDown, bigSpeed + 1, this));
            }
            if (n == 4)
            {
                addParticipant(new Asteroid(i, 2, xRight, yUp, bigSpeed + 1, this));
                n = 0;
            }

            levelStatus--;
            System.out.println(levelStatus);
            n++;

        }

    }

    /**
     * Clears the screen so that nothing is displayed
     */
    private void clear ()
    {
        pstate.clear();
        display.setLegend("");
        ship = null;
    }

    /**
     * Sets things up and begins a new game.
     */
    private void initialScreen ()
    {
        // Clear the screen
        clear();
        fireBullet = false;

        // Plac asteroids
        placeAsteroids();

        // Place the ship
        placeShip();

        // Reset statistics
        // WRONG
        lives = 3;

        getSprite(lives);

        // Start listening to events (but don't listen twice)
        display.removeKeyListener(this);
        display.addKeyListener(this);

        // Give focus to the game screen
        display.requestFocusInWindow();
    }

    /**
     * Adds a new Participant
     */
    public void addParticipant (Participant p)
    {
        pstate.addParticipant(p);
    }

    /**
     * The ship has been destroyed
     */
    public void shipDestroyed ()
    {
        explosion(ship.getX(), ship.getY(), ship.getDirection(), "ShipGone");
        // Null out the ship
        ship = null;

        // Display a legend
        // display.setLegend("Ouch!");

        // Decrement lives
        lives--;
        deleteSprites();
        getSprite(lives);

        if (lives > 0)
        {
            placeShip();

        }
        // Since the ship was destroyed, schedule a transition
        // scheduleTransition(END_DELAY);
    }

    /**
     * An asteroid has been destroyed
     * 
     * @param asteroid
     */
    public void asteroidDestroyed (Asteroid asteroid)// NEED FOR BREAKING ASTRIODS INTO SMALLER PIECES
    {

        // Random rand = new Random();
        // These random numbers are used to generate random asteroid pieces to make the game seem more "realistic".
        int n = RANDOM.nextInt(3);
        int i = RANDOM.nextInt(3);
        // This random number is used to randomize the speed, space physics stuff i guess.

        // If all the asteroids are gone, schedule a transition

        int medSpeed = RANDOM.nextInt(MAXIMUM_MEDIUM_ASTEROID_SPEED - 1);
        int smallSpeed = RANDOM.nextInt(MAXIMUM_SMALL_ASTEROID_SPEED - 1);
        if (countAsteroids() == 0)
        {
            scheduleTransition(END_DELAY);
        }
        if (asteroid.getSize() == 2)
        {
            score = score + 20;
            explosion(20, 40, 3, "Score");
            explosion(asteroid.getX() + n, asteroid.getY(), asteroid.getDirection() + n, "AsteroidGone");

            addParticipant(new Asteroid(i, 1, asteroid.getX(), asteroid.getY(), medSpeed + 1, this));
            addParticipant(new Asteroid(n, 1, asteroid.getX(), asteroid.getY(), medSpeed + 1, this));
            explosion(asteroid.getX() + n, asteroid.getY(), asteroid.getDirection() + n, "Dust");
            Participant.expire(asteroid);

        }
        if (asteroid.getSize() == 1)
        {
            score = score + 50;
            explosion(20, 40, 3, "Score");
            // generate dust? Set inert
            addParticipant(new Asteroid(n, 0, asteroid.getX(), asteroid.getY(), smallSpeed + 1, this));
            addParticipant(new Asteroid(i, 0, asteroid.getX(), asteroid.getY(), smallSpeed + 1, this));
            explosion(asteroid.getX() + n, asteroid.getY(), asteroid.getDirection() + n, "AsteroidGone2");
            explosion(asteroid.getX() + n, asteroid.getY(), asteroid.getDirection() + n, "Dust");
        }
        if (asteroid.getSize() == 0)
        {
            score = score + 100;
            explosion(20, 40, 3, "Score");
            explosion(asteroid.getX() + n, asteroid.getY(), asteroid.getDirection() + n, "AsteroidGone2");
            explosion(asteroid.getX() + n, asteroid.getY(), asteroid.getDirection() + n, "Dust");
            // Determines if when to start a new level or not.

        }

    }

    /**
     * Used to make a new level.
     */
    public void newLevel ()
    {

        //scheduleTransition(5000);
        level++;
        clear();

        fireBullet = false;

        // Plac asteroids
        placeAsteroids();

        // Place the ship
        placeShip();
        //scheduleTransition(50000);

        // controller.display.removeKeyListener(this);
        // controller.display.addKeyListener(this);

        // Give focus to the game screen
        // controller. display.requestFocusInWindow();

    }

    /**
     * Returns the current score of the game
     * 
     * @return
     */
    public String getScore ()
    {
        String s = Integer.toString(score);
        return s;
    }

    public String getLevel() 
    {
        String s = Integer.toString(level);
        return s;
    }

    /**
     * Generates a random Explosion on the screen, relative to where the object that is exploded is
     * 
     * @param x
     * @param y
     * @param d
     * @param c
     * @param s
     */
    public void explosion (double x, double y, double d, String s)
    {
        if(s.equals("NewLevel")) {
            
            for (int n = 0; n < 20; n++)
            {
                int r = RANDOM.nextInt(7);
                addParticipant(new Effects(x + r, y + r, d + r, this, s));
            }
        }
        else {
        // int r = RANDOM.nextInt(4);
        for (int n = 0; n < 4; n++)
        {
            int r = RANDOM.nextInt(7);
            addParticipant(new Effects(x + r, y + r, d + r, this, s));
        }
        }
    }

    /**
     * Schedules a transition m msecs in the future
     */
    private void scheduleTransition (int m) // THE DESIRED TRANSITION TIME
    {
        transitionTime = System.currentTimeMillis() + m;
    }
    
    public void scheduleTransition2 (int m) // THE DESIRED TRANSITION TIME
    {
        scheduleTransition(m);
    }

    /**
     * This method will be invoked because of button presses and timer events.
     */
    @Override
    public void actionPerformed (ActionEvent e)// IMPORTATANT
    {
        // The start button has been pressed. Stop whatever we're doing
        // and bring up the initial screen
        if (e.getSource() instanceof JButton)
        {
            initialScreen();
        }

        // Time to refresh the screen and deal with keyboard input
        else if (e.getSource() == refreshTimer && ship != null)
        {
            if (ammo.size() > 8)
            {
                fireRate = false;
                if (ammo.get(0).isExpired())
                {
                    ammo.remove(0);
                    fireRate = true;
                }
            }

        }
        // direction = ship.getDirection();
        // It may be time to make a game transition
        performTransition();

        if (ship != null)
        {
            if (left == true)
            {
                ship.turnLeft();
            }

            if (right == true)
            {
                ship.turnRight();

            }

        }
        // Null here because when ship methods are invoked on a null object it causes the game to crash.
        if (acc == true && ship != null)
        {
            // Random number generation used for the flame animation
            Random rand = new Random();
            int n = rand.nextInt(2);
            if (n == 1)
            {

                ship.drawaltFlame();

            }
            else
            {

                ship.drawFlame();

            }

            ship.accelerate();

        }

        // Move the participants to their new locations
        pstate.moveParticipants();

        // Refresh screen
        display.refresh();
    }

    /**
     * If the transition time has been reached, transition to a new state
     */
    private void performTransition ()
    {
        // Do something only if the time has been reached
        if (transitionTime <= System.currentTimeMillis())
        {
            
            if(getAteroidsCount() == 0) {
            
             newLevel();   
            }
            
            
            // Clear the transition time
            transitionTime = Long.MAX_VALUE;

            // If there are no lives left, the game is over. Show the final
            // screen.
            if (lives <= 0)
            {
                finalScreen();
            }
        }
    }

    /**
     * Returns the number of asteroids that are active participants
     */
    private int countAsteroids ()
    {
        int count = 0;
        for (Participant p : this)
        {
            if (p instanceof Asteroid)
            {
                count++;
            }

        }
        return count;
    }

    /**
     * deletes the sprites on the screen.
     */
    private void deleteSprites ()
    {
        // int count = 0;
        for (Participant p : this)
        {
            if (p instanceof LifeSprite)
            {
                ((LifeSprite) p).deleteSprite();
            }

        }
        // return count;
    }

    /**
     * Returns the number of asteroids that are active participants for the screen to draw on.
     * 
     * @return
     */
    public int getAteroidsCount ()
    {
        return countAsteroids();
    }

    /**
     * creates a life sprite and adds it to the string
     * 
     * @param x its x position
     * @param y its y position
     */
    public void getSprite (int type)
    {
        // Manually draw how many lifes there are.
        if (type == 1)
        {
            LifeSprite first = new LifeSprite(25, 75);
            this.addParticipant(first);
            explosion(first.getX() + 30, first.getY(), 3, "LifeGone");
            return;
        }

        if (type == 2)
        {
            LifeSprite first = new LifeSprite(25, 75);
            this.addParticipant(first);
            // Second life
            LifeSprite second = new LifeSprite(55, 75);
            this.addParticipant(second);

            explosion(second.getX() + 30, second.getY(), 3, "LifeGone");
            return;
        }

        if (type == 3)
        {
            LifeSprite first = new LifeSprite(25, 75);
            this.addParticipant(first);
            // Second life
            LifeSprite second = new LifeSprite(55, 75);
            this.addParticipant(second);
            LifeSprite third = new LifeSprite(85, 75);
            this.addParticipant(third);
            return;
        }

    }

    /**
     * If a key of interest is pressed, record that it is down.
     */
    @Override
    public void keyPressed (KeyEvent e)
    {

        if ((e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) && ship != null)// Add more methods.
        {
            // Modify shipturn Right? or modify the frame refresh rate?

            acc = true;

        }
        if ((e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) && ship != null)// Add more
                                                                                                     // methods.
        {
            // Modify shipturn Right? or modify the frame refresh rate?

            right = true;

        }

        if ((e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) && ship != null)// Add more methods.
        {
            // Modify shipturn Right? or modify the frame refresh rate?
            left = true;
            // ship.turnLeft();

        }
        // *********************
        if ((e.getKeyCode() == KeyEvent.VK_SPACE || e.getKeyCode() == KeyEvent.VK_DOWN
                || e.getKeyCode() == KeyEvent.VK_S) && ship != null)// Add more methods.
        {
            // Add Shoot animation method, it might be to much though definitely needs a buffer or rate of fire cap;
            //

            if (fireRate == true)
            {
                fireBullet();
                // fireRate = false;

            }
        }

        ;

    }

    /**
     * Draws a new bullet on the screen relative to ships position
     */
    private void fireBullet ()
    {
        // if (ammo.size() < 9)
        // {

        bullet = new Bullet(ship.getXNose(), ship.getYNose(), ship.getRotation(), this);
        addParticipant(bullet);
        ammo.add(bullet);

        // fireBullet = false;

    }

    @Override
    public void keyTyped (KeyEvent e)
    {
    }

    @Override
    public void keyReleased (KeyEvent e)
    {
        if ((e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) && ship != null)// Add more methods.
        {

            acc = false;
            // Gets rid of the flame after the space button is released.
            ship.eraseFlame();

        }

        if ((e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) && ship != null)// Add more methods.
        {

            // Modify shipturn Right? or modify the frame refresh rate?
            left = false;

        }

        if ((e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) && ship != null)// Add more
                                                                                                     // methods.
        {

            // Modify shipturn Right? or modify the frame refresh rate?
            right = false;

        }
    }
}
