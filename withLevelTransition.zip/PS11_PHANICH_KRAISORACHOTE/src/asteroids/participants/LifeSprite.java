package asteroids.participants;

import java.awt.Shape;
import java.awt.geom.Path2D;
import asteroids.game.Participant;

public class LifeSprite extends Participant
{

    /** The outline of the ship */
    private Shape outline;
    
    private int x;
    
    private int y;

    public LifeSprite (int x2, int y2)
    {

        Path2D.Double poly = new Path2D.Double();
        poly.moveTo(21, 0);
        poly.lineTo(-21, 12);
        poly.lineTo(-14, 10);
        poly.lineTo(-14, -10);
        poly.lineTo(-21, -12);
        poly.closePath();
        x = x2;
        y = y2;
        setPosition(x, y);
        setRotation(4.7);
        outline = poly;

    }


    @Override
    protected Shape getOutline ()
    {
        //setPosition(x, y);
        return outline;
    }
    
    public void deleteSprite()
    {
        expire(this);
    
    }
    

    @Override
    public void collidedWith (Participant p)
    {
        // TODO Auto-generated method stub

    }

}
