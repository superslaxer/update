package asteroids.destroyers;
/*
 * use to mark ship
 */
public interface AlienShipDestroyer
{

}
