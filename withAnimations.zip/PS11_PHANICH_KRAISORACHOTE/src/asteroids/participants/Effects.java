package asteroids.participants;

import java.awt.Shape;
import asteroids.destroyers.Animation;
import asteroids.game.Participant;
import asteroids.game.ParticipantCountdownTimer;
import static asteroids.game.Constants.*;
import java.awt.geom.*;
import asteroids.game.Controller;


public class Effects extends Participant implements Animation
{
    /** The outline of the ship */
    private Shape outline;

    /** Game controller */
    private Controller controller;
    
    private double n;
    
    private int a;


    /**
     * Constructs an effect at the specified coordinates that is pointed in the given direction.
     * x posistion of object
     * y position of object 
     * direction of object
     * efffectType that needs to be drawn.
     */
    public Effects (double d, double e, double direction, Controller controller,String effectType)
    {
        
        this.controller = controller;
        setPosition(d, e);
        setRotation(direction);
        
       n = direction;
        Path2D.Double poly = new Path2D.Double();
        
        
        if(effectType.equals("AsteroidGone") ) 
        {
            a = 5;
            poly.moveTo(10, 0);
            poly.lineTo(24, 12);
            accelerate(a);
            poly.closePath();
            outline = poly;
            new ParticipantCountdownTimer(this, "end", 1000);
            
        }
        
        if(effectType.equals("AsteroidGone2") ) 
        {
            a = 5;
            poly.moveTo(10, 0);
            poly.lineTo(1, 1);
            accelerate(a);
            poly.closePath();
            outline = poly;
            new ParticipantCountdownTimer(this, "end", 1000);
            
        }
        if(effectType.equals("ShipGone") ) 
        {
            //a = 15;
            int r = RANDOM.nextInt(11);
            poly.moveTo(10, 0);
            poly.lineTo(r, 10);
            poly.lineTo(r, -10);
            poly.closePath();
            outline = poly;
            //accelerate(a);
            new ParticipantCountdownTimer(this, "end", 1000);
            
        }
        

        
        


        
    }
    @Override
    protected Shape getOutline ()
    {
        n = n + 1;
        //a--;
        //accelerate(a);
        //setVelocity(a,n);
        setRotation(n);
       
       // accelerate();
        // TODO Auto-generated method stub
        return outline;
    }

    
    /**
     * Nothing happens because it is an Effect
     */
    @Override
    public void collidedWith (Participant p)
    {
        // TODO Auto-generated method stub
        
    }
    
    /**
     * This method is invoked when a ParticipantCountdownTimer completes its countdown.
     */
    @Override
    public void countdownComplete (Object payload)
    {
        if (payload.equals("end"))
        {
           expire(this);
           
           
        }

    }
    
    

}
