package asteroids.participants;

import java.awt.Shape;
import java.awt.geom.Path2D;
import asteroids.game.Participant;

public class Lives extends Participant
{
    private Shape outline;

    private int x;

    private int y;
    /*
     * Draw the the graphics that represent lives
     */
    public Lives (int x, int y)
    {

        Path2D.Double poly = new Path2D.Double();
        poly.moveTo(21, 0);
        poly.lineTo(-21, 12);
        poly.lineTo(-14, 10);
        poly.lineTo(-14, -10);
        poly.lineTo(-21, -12);
        poly.closePath();
        this.x = x;
        this.y = y;
        setPosition(this.x, this.y);
        setRotation(4.7);
        outline = poly;

    }
    /*
     * Delete one graphic after one life is lost
     */
    public void lifeLost ()
    {
        expire(this);

    }

    @Override
    protected Shape getOutline ()
    {
        // TODO Auto-generated method stub
        return outline;
    }

    @Override
    public void collidedWith (Participant p)
    {
        // TODO Auto-generated method stub

    }

}
