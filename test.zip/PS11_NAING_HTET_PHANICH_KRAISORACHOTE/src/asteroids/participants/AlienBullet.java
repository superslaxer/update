package asteroids.participants;


import java.awt.Shape;
import java.awt.geom.*;
import asteroids.destroyers.*;
import asteroids.game.Participant;
import asteroids.game.ParticipantCountdownTimer;

public class AlienBullet extends Participant implements ShipDestroyer
{

    private Shape outline;//AlienBullet outline
    
    /*
     * Create alien bullet
     */
    public AlienBullet (double x, double y, double direction)
    {
        
        setPosition(x, y);
        setRotation(direction);

        Path2D.Double poly = new Path2D.Double();
        poly.moveTo(6, 0);
        poly.lineTo(-5, 3);
        poly.lineTo(6, 2);
        poly.lineTo(6, -2);

        poly.lineTo(-5, -3);

        poly.closePath();
        outline = poly;

        setVelocity(15, direction);
        new ParticipantCountdownTimer(this, "shoot", 1500);

    }

    /*
     * Returns alien bullet outline
     */
    @Override
    protected Shape getOutline ()
    {
        // TODO Auto-generated method stub
        return outline;
    }
    /*
     * Bullet will destroy the ship and disappears
     */
    @Override
    public void collidedWith (Participant p)
    {
        if (p instanceof AlienShipDestroyer)
        {
            // Assuming p is an asteroid
            Participant.expire(this);

            
            super.expire(this);
        }

    }
    /*
     * Movement of bullet
     */
//    @Override
//    public void move ()
//    {
//        setSpeed(15);
//        super.move();
//    }
    /*
     * Delay for the bullet to disappear
     */
    @Override
    public void countdownComplete (Object payload)

    {
        // I think it works like this
        if (payload.equals("shoot"))
        {
            expire(this);

        }

    }
    
    

}
