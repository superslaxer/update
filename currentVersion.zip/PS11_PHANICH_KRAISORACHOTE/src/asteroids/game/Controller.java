package asteroids.game;

import static asteroids.game.Constants.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.*;
import asteroids.participants.Asteroid;
import asteroids.participants.Bullet;
import asteroids.participants.Effects;
import asteroids.participants.Ship;
import java.util.Random;

/**
 * Controls a game of Asteroids.
 */
public class Controller implements KeyListener, ActionListener, Iterable<Participant>
{
    /** The state of all the Participants */
    private ParticipantState pstate;

    /** The ship (if one is active) or null (otherwise) */
    private Ship ship;

    /** When this timer goes off, it is time to refresh the animation */
    private Timer refreshTimer;

    private Bullet bullet;

    private boolean fireBullet;

    /**
     * The time at which a transition to a new stage of the game should be made. A transition is scheduled a few seconds
     * in the future to give the user time to see what has happened before doing something like going to a new level or
     * resetting the current level.
     */
    private long transitionTime;

    /** Number of lives left */
    private int lives;

    /** The game display */
    private Display display;

    /** used to update the turn of the ship with each frame. */

    private boolean left;

    /** used to update the turn of the ship with each frame. */

    private boolean right;

    /** used to make the acceleration smooth and current with every frame */
    private boolean acc;

    /** Keeps track of the current amount of bullets on the screen */
    private ArrayList<Bullet> ammo;

    /** Determines if the users can fire their bullet or not */
    private boolean fireRate;
    /** The current score of the game. */
    private int score;

    /**
     * Constructs a controller to coordinate the game and screen
     */
    public Controller ()
    {

        score = 0;
        ammo = new ArrayList<Bullet>();
        // Initialize the ParticipantState
        pstate = new ParticipantState();
        fireRate = true;
        // Set up the refresh timer.
        refreshTimer = new Timer(FRAME_INTERVAL, this);// 33 mili seconds drives animation

        // Clear the transitionTime
        transitionTime = Long.MAX_VALUE;

        // Record the display object
        display = new Display(this);

        // Bring up the splash screen and start the refresh timer
        splashScreen();
        display.setVisible(true);
        // Timer starts here
        refreshTimer.start();
    }

    /**
     * This makes it possible to use an enhanced for loop to iterate through the Participants being managed by a
     * Controller.
     */
    @Override
    public Iterator<Participant> iterator ()
    {
        return pstate.iterator();
    }

    /**
     * Returns the ship, or null if there isn't one
     */
    public Ship getShip ()
    {
        return ship;
    }

    /**
     * Configures the game screen to display the splash screen
     */
    private void splashScreen ()
    {
        // Clear the screen, reset the level, and display the legend
        clear();
        display.setLegend("Asteroids");

        // Place four asteroids near the corners of the screen.
        placeAsteroids();
    }

    /**
     * The game is over. Displays a message to that effect.
     */
    private void finalScreen ()
    {
        display.setLegend(GAME_OVER);
        display.removeKeyListener(this);
    }

    /**
     * Place a new ship in the center of the screen. Remove any existing ship first.
     */
    private void placeShip ()
    {
        // Place a new ship
        Participant.expire(ship);
        // sHIP IS MADE HERE
        ship = new Ship(SIZE / 2, SIZE / 2, -Math.PI / 2, this);
        addParticipant(ship);
        display.setLegend("");
    }

    /**
     * Places an asteroid near one corner of the screen. Gives it a random velocity and rotation.
     */
    private void placeAsteroids ()
    {// Need to add randomness pretty easy to do

        addParticipant(new Asteroid(0, 2, 500, 500, 3, this));
        addParticipant(new Asteroid(0, 2, 200, 250, 2, this));
        addParticipant(new Asteroid(0, 2, 100, 0, 3, this));
        addParticipant(new Asteroid(0, 2, 500, 900, 5, this));
    }

    /**
     * Clears the screen so that nothing is displayed
     */
    private void clear ()
    {
        pstate.clear();
        display.setLegend("");
        ship = null;
    }

    /**
     * Sets things up and begins a new game.
     */
    private void initialScreen ()
    {
        // Clear the screen
        clear();
        fireBullet = false;

        // Plac asteroids
        placeAsteroids();

        // Place the ship
        placeShip();

        // Reset statistics
        // WRONG
        lives = 1;

        // Start listening to events (but don't listen twice)
        display.removeKeyListener(this);
        display.addKeyListener(this);

        // Give focus to the game screen
        display.requestFocusInWindow();
    }

    /**
     * Adds a new Participant
     */
    public void addParticipant (Participant p)
    {
        pstate.addParticipant(p);
    }

    /**
     * The ship has been destroyed
     */
    public void shipDestroyed ()
    {
        explosion(ship.getX(), ship.getY(), ship.getDirection(), "ShipGone");
        // Null out the ship
        ship = null;

        // Display a legend
        display.setLegend("Ouch!");

        // Decrement lives
        lives--;

        // Since the ship was destroyed, schedule a transition
        scheduleTransition(END_DELAY);
    }

    /**
     * An asteroid has been destroyed
     * 
     * @param asteroid
     */
    public void asteroidDestroyed (Asteroid asteroid)// NEED FOR BREAKING ASTRIODS INTO SMALLER PIECES
    {

        Random rand = new Random();
        // These random numbers are used to generate random asteroid pieces to make the game seem more "realistic".
        int n = rand.nextInt(3);
        int i = rand.nextInt(3);
        // This random number is used to randomize the speed, space physics stuff i guess.
        int x = rand.nextInt(2);
        // Don't want it to be zero or else the asteroids will not move!
        x += 1;
        // If all the asteroids are gone, schedule a transition
        if (countAsteroids() == 0)
        {
            scheduleTransition(END_DELAY);
        }
        if (asteroid.getSize() == 2)
        {
            score = score + 20;
            explosion(asteroid.getX() + n, asteroid.getY(), asteroid.getDirection() + n, "AsteroidGone");

            addParticipant(new Asteroid(i, 1, asteroid.getX(), asteroid.getY(), x + 1, this));
            addParticipant(new Asteroid(n, 1, asteroid.getX(), asteroid.getY(), x, this));
        }
        if (asteroid.getSize() == 1)
        {
            score = score + 50;
            // generate dust? Set inert
            addParticipant(new Asteroid(n, 0, asteroid.getX(), asteroid.getY(), x + 1, this));
            addParticipant(new Asteroid(i, 0, asteroid.getX(), asteroid.getY(), x, this));
            explosion(asteroid.getX() + n, asteroid.getY(), asteroid.getDirection() + n, "AsteroidGone2");
        }
        if (asteroid.getSize() == 0)
        {
            score = score + 100;
            explosion(asteroid.getX() + n, asteroid.getY(), asteroid.getDirection() + n, "AsteroidGone2");
        }

    }

    /**
     * Returns the current score of the game
     * 
     * @return
     */
    public String getScore ()
    {
        String s = Integer.toString(score);
        return s;
    }

    /**
     * Generates a random Explosion on the screen, relative to where the object that is exploded is
     * 
     * @param x
     * @param y
     * @param d
     * @param c
     * @param s
     */
    public void explosion (double x, double y, double d, String s)
    {
        // int r = RANDOM.nextInt(4);
        for (int n = 0; n < 20; n++)
        {
            int r = RANDOM.nextInt(7);
            addParticipant(new Effects(x + r, y + r, d + r, this, s));
        }
    }

    /**
     * Schedules a transition m msecs in the future
     */
    private void scheduleTransition (int m) // THE DESIRED TRANSITION TIME
    {
        transitionTime = System.currentTimeMillis() + m;
    }

    /**
     * This method will be invoked because of button presses and timer events.
     */
    @Override
    public void actionPerformed (ActionEvent e)// IMPORTATANT
    {
        // The start button has been pressed. Stop whatever we're doing
        // and bring up the initial screen
        if (e.getSource() instanceof JButton)
        {
            initialScreen();
        }

        // Time to refresh the screen and deal with keyboard input
        else if (e.getSource() == refreshTimer && ship != null)
        {
            if (ammo.size() > 8)
            {
                fireRate = false;
                if (ammo.get(0).isExpired())
                {
                    ammo.remove(0);
                    fireRate = true;
                }
            }

        }
        // direction = ship.getDirection();
        // It may be time to make a game transition
        performTransition();

        if (ship != null)
        {
            if (left == true)
            {
                ship.turnLeft();
            }

            if (right == true)
            {
                ship.turnRight();

            }

        }
        // Null here because when ship methods are invoked on a null object it causes the game to crash.
        if (acc == true && ship != null)
        {
            // Random number generation used for the flame animation
            Random rand = new Random();
            int n = rand.nextInt(2);
            if (n == 1)
            {

                ship.drawaltFlame();

            }
            else
            {

                ship.drawFlame();

            }

            ship.accelerate();

        }

        // Move the participants to their new locations
        pstate.moveParticipants();

        // Refresh screen
        display.refresh();
    }

    /**
     * If the transition time has been reached, transition to a new state
     */
    private void performTransition ()
    {
        // Do something only if the time has been reached
        if (transitionTime <= System.currentTimeMillis())
        {
            // Clear the transition time
            transitionTime = Long.MAX_VALUE;

            // If there are no lives left, the game is over. Show the final
            // screen.
            if (lives <= 0)
            {
                finalScreen();
            }
        }
    }

    /**
     * Returns the number of asteroids that are active participants
     */
    private int countAsteroids ()
    {
        int count = 0;
        for (Participant p : this)
        {
            if (p instanceof Asteroid)
            {
                count++;
            }

        }
        return count;
    }

    /**
     * If a key of interest is pressed, record that it is down.
     */
    @Override
    public void keyPressed (KeyEvent e)
    {

        if (e.getKeyCode() == KeyEvent.VK_UP && ship != null)// Add more methods.
        {
            // Modify shipturn Right? or modify the frame refresh rate?

            acc = true;

        }
        if (e.getKeyCode() == KeyEvent.VK_RIGHT && ship != null)// Add more methods.
        {
            // Modify shipturn Right? or modify the frame refresh rate?

            right = true;

        }

        if (e.getKeyCode() == KeyEvent.VK_LEFT && ship != null)// Add more methods.
        {
            // Modify shipturn Right? or modify the frame refresh rate?
            left = true;
            // ship.turnLeft();

        }
        // *********************
        if (e.getKeyCode() == KeyEvent.VK_SPACE && ship != null)// Add more methods.
        {
            // Add Shoot animation method, it might be to much though definitely needs a buffer or rate of fire cap;
            //

            if (fireRate == true)
            {
                fireBullet();

            }

            ;

        }

    }

    /**
     * Draws a new bullet on the screen relative to ships position
     */
    private void fireBullet ()
    {
        // if (ammo.size() < 9)
        // {

        bullet = new Bullet(ship.getXNose(), ship.getYNose(), ship.getRotation(), this);
        addParticipant(bullet);
        ammo.add(bullet);
        // fireBullet = false;

    }

    @Override
    public void keyTyped (KeyEvent e)
    {
    }

    @Override
    public void keyReleased (KeyEvent e)
    {
        if (e.getKeyCode() == KeyEvent.VK_UP && ship != null)// Add more methods.
        {

            acc = false;
            // Gets rid of the flame after the space button is released.
            ship.eraseFlame();

        }

        if (e.getKeyCode() == KeyEvent.VK_LEFT && ship != null)// Add more methods.
        {

            // Modify shipturn Right? or modify the frame refresh rate?
            left = false;

        }

        if (e.getKeyCode() == KeyEvent.VK_RIGHT && ship != null)// Add more methods.
        {

            // Modify shipturn Right? or modify the frame refresh rate?
            right = false;

        }
    }
}
